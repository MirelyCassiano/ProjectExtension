const { useState, useEffect } = React;

function App(){
  const [items, setItems] = useState(() => {
    try{ return JSON.parse(localStorage.getItem('ext_items')||'[]') }catch(e){return []}
  });
  const [form, setForm] = useState({titulo:'', publico:'', descricao:''});

  useEffect(()=>{ localStorage.setItem('ext_items', JSON.stringify(items)) },[items]);

  function handleChange(e){
    const {name,value} = e.target; setForm(f=>({...f,[name]:value}));
  }

  function handleSubmit(e){
    e.preventDefault();
    if(!form.titulo.trim()) return alert('Insira um título');
    const novo = {id:Date.now(), ...form};
    setItems(prev=>[novo,...prev]);
    setForm({titulo:'', publico:'', descricao:''});
  }

  function removeItem(id){ setItems(prev=>prev.filter(i=>i.id!==id)); }

  return (
    <div className="app-container">
      <header className="mb-3">
        <h1 className="h4">Programa de Extensão - UFMS Digital</h1>
        <p className="text-muted">Gerencie ações de extensão rapidamente</p>
      </header>

      <main className="d-flex gap-3 flex-column flex-lg-row">
        <section className="col-lg-5 app-card" aria-labelledby="form-title">
          <h2 id="form-title" className="h5">Cadastrar Ação</h2>
          <form onSubmit={handleSubmit} className="mt-2">
            <div className="mb-2">
              <label className="form-label" htmlFor="titulo">Título</label>
              <input id="titulo" name="titulo" className="form-control" value={form.titulo} onChange={handleChange} required />
            </div>
            <div className="mb-2">
              <label className="form-label" htmlFor="publico">Público-alvo</label>
              <input id="publico" name="publico" className="form-control" value={form.publico} onChange={handleChange} />
            </div>
            <div className="mb-2">
              <label className="form-label" htmlFor="descricao">Descrição</label>
              <textarea id="descricao" name="descricao" className="form-control" rows="4" value={form.descricao} onChange={handleChange}></textarea>
            </div>
            <div className="d-flex gap-2">
              <button className="btn btn-primary" type="submit">Salvar</button>
              <button className="btn btn-outline-secondary" type="button" onClick={()=>setForm({titulo:'',publico:'',descricao:''})}>Limpar</button>
            </div>
          </form>
        </section>

        <section className="col app-card" aria-labelledby="list-title">
          <h2 id="list-title" className="h5">Ações cadastradas</h2>
          {items.length===0 ? (
            <p className="text-muted">Nenhuma ação cadastrada. Use o formulário para adicionar.</p>
          ) : (
            <ul className="list-group mt-2">
              {items.map(it=> (
                <li key={it.id} className="list-group-item d-flex justify-content-between align-items-start">
                  <div>
                    <div className="fw-bold">{it.titulo}</div>
                    <div className="small text-muted">{it.publico}</div>
                    <div className="mt-1">{it.descricao}</div>
                  </div>
                  <div>
                    <button className="btn btn-sm btn-outline-danger" aria-label={'Remover ' + it.titulo} onClick={()=>removeItem(it.id)}>Remover</button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>
      </main>
    </div>
  )
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />)
