# Programa de Extensão - UFMS Digital (Protótipo)

Protótipo desenvolvido para a Avaliação do Módulo 2 - Desenvolvimento Web com frameworks e HTML/CSS.

## Tecnologias
- HTML5
- CSS3 + Bootstrap 5
- React (via CDN)

## Como executar
Basta abrir o arquivo `index.html` no navegador.

## Estrutura
- index.html
- css/style.css
- js/app.js
